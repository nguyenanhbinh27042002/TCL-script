This repository provides several TCL Scripts used in VLSI Physical Design to extract the information or solve issues/violations.
